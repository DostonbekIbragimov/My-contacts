package com.example.mycontacts.ui.screens

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mycontacts.R
import com.example.mycontacts.data.preferences.LocalStorage
import com.example.mycontacts.data.source.room.AppDatabase
import com.example.mycontacts.ui.adapters.AdminAdapter
import com.example.mycontacts.ui.dialogs.AdminDialog
import kotlinx.android.synthetic.main.activity_contact.*

class AdminActivity : AppCompatActivity() {
    private val adapter = AdminAdapter()
    private val db = AppDatabase.instance
    private val userDao = db.userDao()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        title = "All users"
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        if (AppDatabase.instance.userDao().getAll().size != -1) {
            adapter.submitList(userDao.getAll())
        }

        adapter.setOnItemClickListener {
            LocalStorage.instance.activeUser = userDao.getUser(it.login, it.password)
            startActivity(Intent(this, ContactActivity::class.java))
        }
        adapter.setOnItemDeleteListener {
            userDao.delete(it)
            adapter.removeItem(it)
        }
        adapter.setOnItemEditListener {
            val dialog = AdminDialog(this, "Edit")
            dialog.setStudentData(it)
            dialog.setOnClickListener {
                userDao.update(it)
                adapter.updateItem(it)
            }
            dialog.show()
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.menuAdd -> {
                val dialog = AdminDialog(this,"Add")
                dialog.setOnClickListener {
                    val id = userDao.insert(it)
                    it.id = id
                    adapter.insertItem(it)
                }
                dialog.show()
            }
        }
        return true
    }
}
