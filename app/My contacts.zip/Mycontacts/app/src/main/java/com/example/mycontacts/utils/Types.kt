package com.example.mycontacts.utils

typealias SingleBlock <T> = (T) -> Unit