package com.example.mycontacts.ui.screens

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mycontacts.R
import com.example.mycontacts.data.source.room.AppDatabase
import com.example.mycontacts.data.source.room.dao.UsersWithOutIdData
import com.example.mycontacts.data.source.room.entity.UserData
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : AppCompatActivity() {
    private val db = AppDatabase.instance
    private val userDao = db.userDao()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        buttonRegister.setOnClickListener {
            savedUserData()
        }
    }

    private fun savedUserData() {
        val fullName = register_full_name.text.toString()
        val login = register_username.text.toString()
        val passwordOne = register_password.text.toString()
        val passwordTwo = re_register_password.text.toString()
        if (passwordOne != passwordTwo) {
            makeToast("Confirm password isn't the same!")
            return
        }
        val temp = UsersWithOutIdData(fullName = fullName, login = login, password = passwordOne)
        if (userDao.getUsersWithoutId().contains(temp)) {
            makeToast("The account already exits!")
            return
        }
        userDao.insert(UserData(fullName = fullName, login = login, password = passwordOne))
        Log.d("TTT", db.userDao().getAll().toString())
        makeToast("Successfully!")
        val intent = Intent(this, LoginActivity::class.java)
        intent.putExtra("LOGIN", login)
        intent.putExtra("PASSWORD", passwordOne)
        startActivity(intent)
        finish()
        startActivity(intent)
    }

    private fun makeToast(txt: String) {
        Toast.makeText(this, txt, Toast.LENGTH_SHORT).show()
    }
}
