package com.example.mycontacts.ui.screens

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mycontacts.R
import com.example.mycontacts.data.preferences.LocalStorage
import com.example.mycontacts.data.source.room.AppDatabase
import com.example.mycontacts.data.source.room.dao.LoginPassword
import com.example.mycontacts.utils.extensions.toEditable
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    private var login: String = ""
    private var password: String = ""
    private val db = AppDatabase.instance
    private val userDao = db.userDao()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        buttonLogin.setOnClickListener {
            loginContact()
        }
        loadFromRegisterToLogin()
    }

    private fun loadFromRegisterToLogin() {
        val bundle = intent.extras
        if (bundle != null) {
            login = bundle.getString("LOGIN", "null")
            password = bundle.getString("PASSWORD", "null")
        }
        login_username.text = login.toEditable()
        login_password.text = password.toEditable()
    }

    private fun loginContact() {
        val login = login_username.text.toString()
        val password = login_password.text.toString()
        if (login.isEmpty() && password.isEmpty()) {
            makeToast("Enter login and password")
            return
        }
        if (login.isEmpty()) {
            makeToast("Enter login!")
            return
        }
        if (password.isEmpty()) {
            makeToast("Enter password")
            return
        }

        if (login == "admin" && password == "password") {
            startActivity(Intent(this, AdminActivity::class.java))
            return
        }
        if (!userDao.getLoginPassword().contains(LoginPassword(login, password))) {
            makeToast("This account isn't exist!\nYou must register!")
            return
        }

        LocalStorage.instance.activeUser = userDao.getUser(login, password)
        startActivity(Intent(this, ContactActivity::class.java))
        login_username.text!!.clear()
        login_password.text!!.clear()
        finish()
    }

    private fun makeToast(txt: String) {
        Toast.makeText(this, txt, Toast.LENGTH_SHORT).show()
    }
}
