package com.example.mycontacts.ui.screens

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mycontacts.R
import com.example.mycontacts.data.preferences.LocalStorage
import com.example.mycontacts.data.source.room.AppDatabase
import com.example.mycontacts.data.source.room.entity.ContactData
import com.example.mycontacts.ui.adapters.ContactAdapter
import com.example.mycontacts.ui.dialogs.ContactDialog
import com.getbase.floatingactionbutton.FloatingActionsMenu
import kotlinx.android.synthetic.main.activity_contact.*
import kotlinx.android.synthetic.main.edit_item.*

class ContactActivity : AppCompatActivity() {
    private val adapter = ContactAdapter()
    private val db = AppDatabase.instance
    private val contactDao = db.contactDao()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        if (AppDatabase.instance.contactDao().getAll().size != -1) {
            adapter.submitList(contactDao.filterCourseById(LocalStorage.instance.activeUser.id))
        }

        adapter.setOnItemClickListener {
            Toast.makeText(this, "Yesss", Toast.LENGTH_SHORT).show()
        }
        adapter.setOnItemDeleteListener {
            contactDao.delete(it)
            adapter.removeItem(it)
        }
        adapter.setOnItemEditListener {
            val dialog = ContactDialog(this, "Edit")
            dialog.setStudentData(it)
            dialog.setOnClickListener {
                contactDao.update(it)
                adapter.updateItem(it)
            }
            dialog.show()
        }
        initFloatingActionButtonMenu()
    }

    private fun initFloatingActionButtonMenu() {

        multiple_menu_check.setOnFloatingActionsMenuUpdateListener(object :
            FloatingActionsMenu.OnFloatingActionsMenuUpdateListener {
            override fun onMenuExpanded() {
                floating_menu_background_check.visibility = View.VISIBLE
            }

            override fun onMenuCollapsed() {
                floating_menu_background_check.visibility = View.GONE
            }
        })

        action_add_contact_queue_check.setOnClickListener {
            showAlertDialog()
            multiple_menu_check.collapse()
        }
        action_delete_to_queue_check.setOnClickListener {
            contactDao.deleteAll(contactDao.getAll())
            adapter.removeAll()
            multiple_menu_check.collapse()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showAlertDialog() {
        val mDialogView = LayoutInflater.from(this).inflate(R.layout.edit_item, null)
        val mBuilder = AlertDialog.Builder(this)
            .setView(mDialogView)
        val mAlertDialog = mBuilder.show()

        mAlertDialog.edit_delete_dialog.text = "Add"

        mAlertDialog.edit_delete_dialog.setOnClickListener {
            val name = mAlertDialog.name_dialog.text.toString()
            val surname = mAlertDialog.surname_dialog.text.toString()
            if (name.isEmpty() || surname.isEmpty()) {
                showToast("Please, enter name and phone!")
            } else {

                val temp = ContactData(
                    name = name,
                    email = surname,
                    userId = LocalStorage.instance.activeUser.id
                )
                contactDao.insert(temp)
                adapter.insertItem(temp)
                mAlertDialog.dismiss()
            }
        }
        mAlertDialog.cancel_dialog.setOnClickListener { mAlertDialog.dismiss() }
    }

    private fun showToast(str: String) {
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show()
    }
}
